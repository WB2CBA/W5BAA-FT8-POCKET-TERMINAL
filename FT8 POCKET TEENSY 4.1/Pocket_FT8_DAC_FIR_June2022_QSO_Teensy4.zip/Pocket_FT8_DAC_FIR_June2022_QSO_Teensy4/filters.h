// Number of coefficients
#define HILBERT_COEFFS 128
extern short RX_hilbert45[];
//extern short RX_hilbertm45[];
